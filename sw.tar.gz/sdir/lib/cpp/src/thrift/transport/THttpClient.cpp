/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

#include <algorithm>
#include <boost/algorithm/string.hpp>
#include <cstdlib>
#include <limits>
#include <sstream>
#include <vector>

#include <thrift/config.h>
#include <thrift/transport/THttpClient.h>
#include <thrift/transport/TSocket.h>

using std::string;

namespace apache {
namespace thrift {
namespace transport {

THttpClient::THttpClient(std::shared_ptr<TTransport> transport,
                         std::string host,
                         std::string path,
                         std::shared_ptr<TConfiguration> config)
  : THttpTransport(transport, config),
    host_(host),
    path_(path),
    onewayResponsePending_(false),
    closeAfterResponse_(false) {}

THttpClient::THttpClient(string host, int port, string path, std::shared_ptr<TConfiguration> config)
  : THttpTransport(std::shared_ptr<TTransport>(new TSocket(host, port)), config),
    host_(host),
    path_(path),
    onewayResponsePending_(false),
    closeAfterResponse_(false) {}

THttpClient::~THttpClient() = default;

void THttpClient::close() {
  onewayResponsePending_ = false;
  closeAfterResponse_ = false;
  readBuffer_.resetBuffer();
  readHeaders_ = true;
  chunked_ = false;
  chunkedDone_ = false;
  chunkSize_ = 0;
  contentLength_ = 0;
  httpPos_ = 0;
  httpBufLen_ = 0;
  httpBuf_[0] = '\0';
  THttpTransport::close();
}

void THttpClient::parseHeader(char* header) {
  char* colon = strchr(header, ':');
  if (colon == nullptr) {
    return;
  }
  char* value = colon + 1;

  const string name(header, colon);
  if (boost::iequals(name, "Transfer-Encoding")) {
    if (boost::iends_with(value, "chunked")) {
      chunked_ = true;
    }
  } else if (boost::iequals(name, "Content-Length")) {
    chunked_ = false;
    contentLength_ = parseContentLength(value);
  } else if (boost::iequals(name, "Connection")) {
    std::vector<string> options;
    boost::split(options, value, boost::is_any_of(","));
    for (const string& option : options) {
      if (boost::iequals(boost::trim_copy(option), "close")) {
        closeAfterResponse_ = true;
        break;
      }
    }
  }
}

bool THttpClient::parseStatusLine(char* status) {
  closeAfterResponse_ = false;
  char* http = status;

  char* code = strchr(http, ' ');
  if (code == nullptr) {
    throw TTransportException(string("Bad Status: ") + status);
  }

  *code = '\0';
  while (*(code++) == ' ') {
  };

  char* msg = strchr(code, ' ');
  if (msg == nullptr) {
    throw TTransportException(string("Bad Status: ") + status);
  }
  *msg = '\0';

  if (strcmp(code, "200") == 0) {
    // HTTP 200 = OK, we got the response
    return true;
  } else if (strcmp(code, "100") == 0) {
    // HTTP 100 = continue, just keep reading
    return false;
  } else {
    throw TTransportException(string("Bad Status: ") + status);
  }
}

void THttpClient::flush() {
  resetConsumedMessageSize();

  uint8_t* buf;
  uint32_t len;
  writeBuffer_.getBuffer(&buf, &len);
  if (len == 0) {
    return;
  }

  if (onewayResponsePending_) {
    if (transport_->isOpen()) {
      drainPendingOnewayResponse();
    } else {
      onewayResponsePending_ = false;
    }
  }

  if (closeAfterResponse_) {
    close();
  }

  if (!transport_->isOpen()) {
    transport_->open();
  }

  // Construct the HTTP header
  std::ostringstream h;
  h << "POST " << path_ << " HTTP/1.1" << CRLF << "Host: " << host_ << CRLF
    << "Content-Type: application/x-thrift" << CRLF << "Content-Length: " << len << CRLF
    << "Accept: application/x-thrift" << CRLF << "User-Agent: Thrift/" << PACKAGE_VERSION
    << " (C++/THttpClient)" << CRLF << CRLF;
  string header = h.str();

  if (header.size() > (std::numeric_limits<uint32_t>::max)())
    throw TTransportException("Header too big");
  // Write the header, then the data, then flush
  transport_->write((const uint8_t*)header.c_str(), static_cast<uint32_t>(header.size()));
  transport_->write(buf, len);
  transport_->flush();

  // Reset the buffer and header variables
  writeBuffer_.resetBuffer();
  readHeaders_ = true;
}

void THttpClient::onewayComplete() {
  onewayResponsePending_ = true;
}

void THttpClient::drainPendingOnewayResponse() {
  readBuffer_.resetBuffer();

  if (readHeaders_) {
    readHeaders();
  }

  if (chunked_) {
    while (!chunkedDone_) {
      char* line = readLine();
      uint32_t chunkSize = parseChunkSize(line);
      if (chunkSize == 0) {
        readChunkedFooters();
        break;
      }

      discardResponseBody(chunkSize);
      readLine();
    }
  } else {
    discardResponseBody(contentLength_);
  }

  readHeaders_ = true;
  onewayResponsePending_ = false;
}

void THttpClient::discardResponseBody(uint32_t size) {
  uint32_t remaining = size;
  while (remaining > 0) {
    uint32_t avail = httpBufLen_ - httpPos_;
    if (avail == 0) {
      httpPos_ = 0;
      httpBufLen_ = 0;
      refill();
      avail = httpBufLen_;
    }

    uint32_t give = (std::min)(remaining, avail);
    httpPos_ += give;
    remaining -= give;
  }
}

void THttpClient::setPath(std::string path) {
  path_ = path;
}
}
}
} // apache::thrift::transport
